package net.codeaurora.superior.apwwalls;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import net.codeaurora.superior.apwwalls.databinding.ActivitySettingsBinding;

public class SettingsActivity extends AppCompatActivity {
    private ActivitySettingsBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, new Settings()).commit();
    }
}
