package net.codeaurora.superior.apwwalls;

import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputLayout;

public class LabsFrag extends androidx.fragment.app.Fragment {
    @Override
    public android.view.View onCreateView(
            android.view.LayoutInflater arg0, android.view.ViewGroup arg1, android.os.Bundle arg2) {
        android.view.View view = arg0.inflate(R.layout.apw_labs, arg1, false);
        LinearLayout lock = view.findViewById(R.id.lock);
        WallpaperManager manager =
                WallpaperManager.getInstance(getActivity().getApplicationContext());
        try {
            ParcelFileDescriptor descriptor = manager.getWallpaperFile(WallpaperManager.FLAG_LOCK);
            if (descriptor != null) {
                Bitmap bitmap = BitmapFactory.decodeFileDescriptor(descriptor.getFileDescriptor());
                Drawable wallpaper =
                        new BitmapDrawable(
                                getActivity().getApplicationContext().getResources(), bitmap);
                lock.setBackgroundDrawable(wallpaper);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        LinearLayout home = view.findViewById(R.id.home);
        home.setBackgroundDrawable(manager.getDrawable());
        TextInputLayout editText = view.findViewById(R.id.outlinedTextField);
            editText.setEndIconOnClickListener(
                    v -> {
                        try {
                            Intent intent =
                                    new Intent(
                                            getActivity().getApplicationContext(),
                                            WallpaperView.class);
                            intent.putExtra(
                                    "wallpaperUrl", editText.getEditText().getText().toString());
                            intent.putExtra("name", "Null/Void");
                            if(editText.getEditText().getText().toString() != null && editText.getEditText().getText().toString() != "") {
                            	startActivity(intent);
                            }
                        } catch (Exception err) {
                            Toast.makeText(
                                            getActivity().getApplicationContext(),
                                            "An error occured",
                                            Toast.LENGTH_LONG)
                                    .show();
                        }
                    });
        return view;
    }
}
