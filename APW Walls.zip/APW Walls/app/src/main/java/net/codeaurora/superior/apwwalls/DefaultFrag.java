package net.codeaurora.superior.apwwalls;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

public class DefaultFrag extends Fragment {
    public String[] xiaomi14 = {
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Xiaomi14wall1.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Xiaomi14wall2.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Xiaomi14wall3.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Xiaomi14wall4.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Xiaomi14wall5.jpg"
    };
    public String[] xiaomiNote13 = {
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/XiaomiNote13Pro1.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/XiaomiNote13Pro2.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/XiaomiNote13Pro3.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/XiaomiNote13Pro4.jpg"
    };
    public String[] pura = {
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/P60Pro1.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/P60Pro2.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/P60Pro3.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/P60Pro4.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/P60Pro5.jpg"
    };
    public String[] op = {
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/OplusOpen1.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/OpluOpen2.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Findx71.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Findx72.jpg"
    };
    public String[] iqoo = {
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Iqoo121.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Iqoo122.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Iqoo123.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Iqoo124.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Iqoo125.jpg"
    };

    @Override
    public View onCreateView(LayoutInflater arg0, ViewGroup arg1, Bundle arg2) {
        View view = arg0.inflate(R.layout.default_view, arg1, false);
        LinearLayout xiaomi1 = (LinearLayout) view.findViewById(R.id.xiaomi14_1);
        LinearLayout xiaomi2 = (LinearLayout) view.findViewById(R.id.xiaomi14_2);
        LinearLayout xiaomi3 = (LinearLayout) view.findViewById(R.id.xiaomi14_3);
        LinearLayout xiaomi4 = (LinearLayout) view.findViewById(R.id.xiaomi14_4);
        LinearLayout xiaomi5 = (LinearLayout) view.findViewById(R.id.xiaomi14_5);
        loadImage(xiaomi14[0], xiaomi1, "Xiaomi 14 Pro 1");
        loadImage(xiaomi14[1], xiaomi2, "Xiaomi 14 Pro 2");
        loadImage(xiaomi14[2], xiaomi3, "Xiaomi 14 Pro 3");
        loadImage(xiaomi14[3], xiaomi4, "Xiaomi 14 Pro 4");
        loadImage(xiaomi14[4], xiaomi5, "Xiaomi 14 Pro 5");
        LinearLayout xiaomi131 = view.findViewById(R.id.xiaomi13_1);
        LinearLayout xiaomi132 = view.findViewById(R.id.xiaomi13_2);
        LinearLayout xiaomi133 = view.findViewById(R.id.xiaomi13_3);
        LinearLayout xiaomi134 = view.findViewById(R.id.xiaomi13_4);
        loadImage(xiaomiNote13[0], xiaomi131, "Xiaomi Note 13 Pro 1");
        loadImage(xiaomiNote13[1], xiaomi132, "Xiaomi Note 13 Pro 2");
        loadImage(xiaomiNote13[2], xiaomi133, "Xiaomi Note 13 Pro 3");
        loadImage(xiaomiNote13[3], xiaomi134, "Xiaomi Note 13 Pro 4");
        LinearLayout pura1 = view.findViewById(R.id.pura1);
        LinearLayout pura2 = view.findViewById(R.id.pura2);
        LinearLayout pura3 = view.findViewById(R.id.pura3);
        LinearLayout pura4 = view.findViewById(R.id.pura4);
        LinearLayout pura5 = view.findViewById(R.id.pura5);
        loadImage(pura[0], pura1, "Huawei P60 Pro 1");
        loadImage(pura[1], pura2, "Huawei P60 Pro 2");
        loadImage(pura[2], pura3, "Huawei P60 Pro 3");
        loadImage(pura[3], pura4, "Huawei P60 Pro 4");
        loadImage(pura[4], pura5, "Huawei p60 Pro 5");
        LinearLayout op1 = view.findViewById(R.id.op1);
        LinearLayout op2 = view.findViewById(R.id.op2);
        LinearLayout op3 = view.findViewById(R.id.op3);
        LinearLayout op4 = view.findViewById(R.id.op4);
        loadImage(op[0], op1, "OnePlus Open 1");
        loadImage(op[1], op2, "OnePlus Open 2");
        loadImage(op[2], op3, "OPPO Find X7 Ultra 1");
        loadImage(op[3], op4, "OPPO Find X7 Ultra 2");
        LinearLayout iqoo121 = (LinearLayout) view.findViewById(R.id.iqoo121);
        LinearLayout iqoo122 = (LinearLayout) view.findViewById(R.id.iqoo122);
        LinearLayout iqoo123 = (LinearLayout) view.findViewById(R.id.iqoo123);
        LinearLayout iqoo124 = (LinearLayout) view.findViewById(R.id.iqoo124);
        LinearLayout iqoo125 = (LinearLayout) view.findViewById(R.id.iqoo125);
        loadImage(iqoo[0], iqoo121, "Vivo Iqoo 12 - 1");
        loadImage(iqoo[1], iqoo122, "Vivo Iqoo 12 - 2");
        loadImage(iqoo[2], iqoo123, "Vivo Iqoo 12 - 3");
        loadImage(iqoo[3], iqoo124, "Vivo Iqoo 12 - 4");
        loadImage(iqoo[4], iqoo125, "Vivo Iqoo 12 - 5");
        return view;
    }

    public void loadImage(String url, LinearLayout image, String name) {
        Glide.with(this)
                .load(url)
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(
                        new CustomTarget<Drawable>() {
                            @Override
                            public void onResourceReady(
                                    Drawable resource, Transition<? super Drawable> transition) {
                                image.setBackground(resource);
                                image.setOnClickListener(
                                        v -> {
                                            Intent intent =
                                                    new Intent(
                                                            getActivity().getApplicationContext(),
                                                            WallpaperView.class);
                                            intent.putExtra("wallpaperUrl", url);
                                            intent.putExtra("name", name);
                                            startActivity(intent);
                                        });
                            }

                            @Override
                            public void onLoadCleared(@Nullable Drawable placeholder) {
                                // Handle placeholder if needed
                            }
                        });
    }
}
