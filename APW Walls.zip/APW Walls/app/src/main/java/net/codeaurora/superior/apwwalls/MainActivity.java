package net.codeaurora.superior.apwwalls;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import kotlin.Function;
import net.codeaurora.superior.apwwalls.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, new DefaultFrag())
                .commit();
        binding.bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem arg0) {
                        if (arg0.getItemId() == R.id.vendors) {
                            getSupportFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.container, new DefaultFrag())
                                    .commit();
                            return true;
                        } else if (arg0.getItemId() == R.id.stocks) {
                            getSupportFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.container, new StockFrag())
                                    .commit();
                            return true;
                        } else if (arg0.getItemId() == R.id.roms) {
                            getSupportFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.container, new LabsFrag())
                                    .commit();
                            return true;
                        }
                        return false;
                    }
                });
    }

    public void updateTitle(int optionId) {
        MenuItem item1 = binding.bottomNavigationView.getMenu().findItem(R.id.vendors);
        MenuItem item2 = binding.bottomNavigationView.getMenu().findItem(R.id.stocks);
        MenuItem item3 = binding.bottomNavigationView.getMenu().findItem(R.id.roms);
        if (optionId == R.id.vendors) {
            item1.setTitle("Vendor Walls");
            item2.setTitle("");
            item3.setTitle("");
        } else if (optionId == R.id.stocks) {
            item1.setTitle("");
            item2.setTitle("Stock Roms");
            item3.setTitle("");
        } else if (optionId == R.id.roms) {
            item1.setTitle("");
            item2.setTitle("");
            item3.setTitle("Custom Roms");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu arg0) {
        getMenuInflater().inflate(R.menu.menu, arg0);
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem arg0) {
        if (arg0.getItemId() == R.id.settings) {
            startActivity(new Intent(this, SettingsActivity.class));
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.binding = null;
    }
}
