package net.codeaurora.superior.apwwalls;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.MainThread;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;

public class StockFrag extends Fragment {
    public String[] oneui = {
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/OneUI1.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/OneUI2.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/OneUI3.jpg",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/OneUI4.jpg"
    };
    public String[] hyperos = {
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/HyperOS1.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/HyperOS2.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/HyperOS3.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/HyperOS4.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/HyperOS5.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/HyperOS6.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/HyperOS7.png"
    };
    public String[] ios = {
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Ios1.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Ios2.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Ios3.png",
        "https://raw.githubusercontent.com/ShabdVasudeva/APW-Walls-Database/main/Ios4.png"
    };
    public String[] evox = {
        "https://raw.githubusercontent.com/Evolution-X/Wallpapers/master/img/Black.png",
        "https://raw.githubusercontent.com/Evolution-X/Wallpapers/master/img/CypherLight.png",
        "https://raw.githubusercontent.com/Evolution-X/Wallpapers/master/img/CypherDark.png",
        "https://raw.githubusercontent.com/Evolution-X/Wallpapers/master/img/LightBluePastel.png",
        "https://raw.githubusercontent.com/Evolution-X/Wallpapers/master/img/Evo-X_2.0_Dark.png"
    };
    @Override
    public View onCreateView(LayoutInflater arg0, ViewGroup arg1, Bundle arg2) {
        View view = arg0.inflate(R.layout.stock_view, arg1, false);
        LinearLayout oneui1 = view.findViewById(R.id.oneui1);
        LinearLayout oneui2 = view.findViewById(R.id.oneui2);
        LinearLayout oneui3 = view.findViewById(R.id.oneui3);
        LinearLayout oneui4 = view.findViewById(R.id.oneui4);
        loadImage(oneui[0],oneui1, "OneUI 5.1 - 1");
        loadImage(oneui[1],oneui2, "OneUI 5.1 - 2");
        loadImage(oneui[2],oneui3, "OneUI 5.1 - 3");
        loadImage(oneui[3],oneui4, "OneUI 5.1 - 4");
        LinearLayout hyperos1 = view.findViewById(R.id.hyperos1);
        LinearLayout hyperos2 = view.findViewById(R.id.hyperos2);
        LinearLayout hyperos3 = view.findViewById(R.id.hyperos3);
        LinearLayout hyperos4 = view.findViewById(R.id.hyperos4);
        LinearLayout hyperos5 = view.findViewById(R.id.hyperos5);
        LinearLayout hyperos6 = view.findViewById(R.id.hyperos6);
        LinearLayout hyperos7 = view.findViewById(R.id.hyperos7);
        loadImage(hyperos[0], hyperos1, "HyperOS 1.O - 1");
        loadImage(hyperos[1], hyperos2, "HyperOS 1.O - 2");
        loadImage(hyperos[2], hyperos3, "HyperOS 1.O - 3");
        loadImage(hyperos[3], hyperos4, "HyperOS 1.O - 4");
        loadImage(hyperos[4], hyperos5, "HyperOS 1.O - 5");
        loadImage(hyperos[5], hyperos6, "HyperOS 1.O - 6");
        loadImage(hyperos[6], hyperos7, "HyperOS 1.O - 7");
        LinearLayout ios1 = view.findViewById(R.id.ios1);
        LinearLayout ios2 = view.findViewById(R.id.ios2);
        LinearLayout ios3 = view.findViewById(R.id.ios3);
        LinearLayout ios4 = view.findViewById(R.id.ios4);
        loadImage(ios[0],ios1, "IOS - 1");
        loadImage(ios[1],ios2, "IOS - 2");
        loadImage(ios[2],ios3, "IOS - 3");
        loadImage(ios[3],ios4, "IOS - 4");
        LinearLayout evox1 = view.findViewById(R.id.evox1);
        LinearLayout evox2 = view.findViewById(R.id.evox2);
        LinearLayout evox3 = view.findViewById(R.id.evox3);
        LinearLayout evox4 = view.findViewById(R.id.evox4);
        LinearLayout evox5 = view.findViewById(R.id.evox5);
        loadImage(evox[0], evox1, "Evolution X - 1");
        loadImage(evox[1], evox2, "Evolution X - 2");
        loadImage(evox[2], evox3, "Evolution X - 3");
        loadImage(evox[3], evox4, "Evolution X - 4");
        loadImage(evox[4], evox5, "Evolution X - 5");
        return view;
    }
    public void loadImage(String url, LinearLayout image, String name) {
        Glide.with(this)
                .load(url)
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(
                        new CustomTarget<Drawable>() {
                            @Override
                            public void onResourceReady(
                                    Drawable resource, Transition<? super Drawable> transition) {
                                image.setBackground(resource);
                                image.setOnClickListener(
                                        v -> {
                                            Intent intent =
                                                    new Intent(
                                                            getActivity().getApplicationContext(),
                                                            WallpaperView.class);
                                            intent.putExtra("wallpaperUrl", url);
                                            intent.putExtra("name", name);
                                            startActivity(intent);
                                        });
                            }

                            @Override
                            public void onLoadCleared(@Nullable Drawable placeholder) {
                                // Handle placeholder if needed
                            }
                        });
    }
}
