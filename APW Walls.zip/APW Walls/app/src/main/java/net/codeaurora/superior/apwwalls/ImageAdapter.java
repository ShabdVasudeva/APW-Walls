package net.codeaurora.superior.apwwalls;

import android.graphics.Bitmap;

public class ImageAdapter{
    private Bitmap bitmap;
    private String wallpaperName;
    public ImageAdapter(Bitmap bitmap, String wallpaperName){
        this.bitmap = bitmap;
        this.wallpaperName = wallpaperName;
    }
    public Bitmap getBitmap(){
        return bitmap;
    }
    public String getName(){
        return wallpaperName;
    }
}