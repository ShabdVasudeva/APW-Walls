package net.codeaurora.superior.apwwalls;

import android.Manifest;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import net.codeaurora.superior.apwwalls.databinding.WallpaperViewBinding;

public class WallpaperView extends AppCompatActivity {
    private WallpaperViewBinding binding;
    private static final int REQUEST_WRITE_STORAGE = 112;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = WallpaperViewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        requestStoragePermissions();
        WindowManager windowManager =
                (WindowManager) getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
        String url = getIntent().getStringExtra("wallpaperUrl");
        String nams = getIntent().getStringExtra("name");
        Display display = windowManager.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int screenWidth = size.x;
        int screenHeight = size.y;
        if (url == null || url.isEmpty()) {
            Toast.makeText(getApplicationContext(), "An error occured", Toast.LENGTH_LONG).show();
        } else {
            Picasso.get()
                    .load(url)
                    .resize(screenWidth, screenHeight)
                    .centerCrop()
                    .into(binding.wallpaperPreview);
            binding.setWall.setOnClickListener(
                    v -> {
                        binding.wallpaperPreview.buildDrawingCache();
                        Bitmap bitmap = binding.wallpaperPreview.getDrawingCache();
                        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
                        builder.setTitle("Set wallpaper as")
                                .setNegativeButton(
                                        "Lockscreen",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                setOnLock(bitmap);
                                            }
                                        })
                                .setPositiveButton(
                                        "Homescreen",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                setOnHome(url);
                                            }
                                        })
                                .setNeutralButton(
                                        "Both",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                setOnLock(bitmap);
                                                setOnHome(url);
                                            }
                                        })
                                .show();
                    });
            binding.info.setOnClickListener(
                    v -> {
                        Toast.makeText(getApplicationContext(), nams, Toast.LENGTH_LONG).show();
                    });
            binding.download.setOnClickListener(
                    v -> {
                        downloadImage(url);
                    });
            binding.tune.setOnClickListener(
                    v -> {
                        Toast.makeText(
                                        getApplicationContext(),
                                        "Black And White effect will be unlocked very soon",
                                        Toast.LENGTH_LONG)
                                .show();
                    });
        }
    }

    private void requestStoragePermissions() {
        boolean hasPermission =
                (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED);
        if (!hasPermission) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQUEST_WRITE_STORAGE);
        }
    }

    private void downloadImage(String url) {
        Picasso.get()
                .load(url)
                .into(
                        new Target() {
                            @Override
                            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                                saveImage(bitmap, "APWwallsImage.jpg");
                            }

                            @Override
                            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                                Toast.makeText(
                                                getApplicationContext(),
                                                "Failed to download Image",
                                                Toast.LENGTH_LONG)
                                        .show();
                            }

                            @Override
                            public void onPrepareLoad(Drawable placeHolderDrawable) {
                                // Optional: Handle placeholder
                            }
                        });
    }

    private void saveImage(Bitmap bitmap, String fileName) {
        File downloadFolder =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File imageFile = new File(downloadFolder, fileName);
        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            Toast.makeText(
                            getApplicationContext(),
                            "Image has been saved successfully to the downloads folder",
                            Toast.LENGTH_LONG)
                    .show();
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(), "Failed to save image", Toast.LENGTH_LONG)
                    .show();
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_WRITE_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with the task
            } else {
                // Permission denied, handle accordingly
                Log.e("Permission", "Write external storage permission denied");
            }
        }
    }

    public void setOnHome(String url) {
        Picasso.get()
                .load(url)
                .into(
                        new Target() {
                            @Override
                            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                                try {
                                    WallpaperManager wallpaperManager =
                                            WallpaperManager.getInstance(getApplicationContext());
                                    wallpaperManager.setBitmap(
                                            bitmap, null, true, WallpaperManager.FLAG_SYSTEM);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                                e.printStackTrace();
                            }

                            @Override
                            public void onPrepareLoad(Drawable placeHolderDrawable) {
                                // Optional: Handle placeholder
                            }
                        });
    }

    public void setOnLock(Bitmap bitmap) {
        WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
        try {
            manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK);
        } catch (Exception err) {

        }
    }
}
