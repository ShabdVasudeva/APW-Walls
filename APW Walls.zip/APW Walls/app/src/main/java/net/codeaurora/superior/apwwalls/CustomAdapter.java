package net.codeaurora.superior.apwwalls;

public class CustomAdapter {
}
